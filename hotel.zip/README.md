This is a Hotel website built using Bootstrap.
